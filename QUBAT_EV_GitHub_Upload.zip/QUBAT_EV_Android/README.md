# QUBAT EV Demo
Android demo application for an EV charging network in Bishkek.

The app contains an interactive OpenStreetMap/Leaflet map, demo charging stations, station list, wallet, charging history, profile/operator sections, and a custom QUBAT EV launcher icon.

GitHub Actions builds `app-debug.apk` and uploads it as the `QUBAT-EV-Demo-APK` workflow artifact.
